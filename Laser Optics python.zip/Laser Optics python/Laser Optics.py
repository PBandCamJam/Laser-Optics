#!/usr/bin/env python
# coding: utf-8

# In[5]:


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# This data was obtained using a photometer to convert the energy from a HeNe laser beam into volts
# A single slit was placed in front of the photometer to produce an interference pattern
# To capture the intensity of the beam, the photometer was placed on a moving platform to capture the entire width of the beam
single_slit_diffraction = pd.read_csv('Laser Optics.csv')

# Deleting empty columns
del single_slit_diffraction['Unnamed: 2']
del single_slit_diffraction['Unnamed: 3']

# Showing the data and the amount of datapoints                           
print(single_slit_diffraction)

# Max intensity is where the center of the beam lies
max_intensity = max(single_slit_diffraction['Potential (Volts)'])

# Scatter plot of Intensity vs. time
# The maximums are the constructive interference from the single slit
# The minimums are the destructive interference from the single slit i.e. no laser beam.
plt.scatter(single_slit_diffraction['Time (s)'], single_slit_diffraction['Potential (Volts)'])

plt.title('Single Slit Diffraction')
plt.xlabel('Time (s)')
plt.ylabel('Intensity (V)')

plt.show()
plt.clf()

print("\nThe center of the HeNe laser beam is at the max intensity of the plot, which is " + str(max_intensity) + " volts." )

